package com.example.android_crud_sqlite;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper myDb;
    EditText editMarca,editModelo,editVelMax,editTextId;
    Button btnAdicionar;
    Button btnTodos;
    Button btnUpdate;
    Button btnDelete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDb = new DatabaseHelper(this);

        editMarca = (EditText) findViewById(R.id.editMarca);
        editModelo = (EditText) findViewById(R.id.editModelo);
        editTextId = (EditText) findViewById(R.id.editTextId);
        editVelMax = (EditText) findViewById(R.id.editVelMax);
        btnAdicionar = (Button) findViewById(R.id.btnAdicionar);
        btnDelete = (Button) findViewById(R.id.btnDelete);
        btnTodos = (Button) findViewById(R.id.btnTodos);
        btnUpdate = (Button) findViewById(R.id.btnUpdate);

        AddData();
        viewAll ();
        UpdateData();
        DeleteData();

    }

    public void DeleteData (){
        btnDelete.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Integer deleteRows = myDb.deleteData(editTextId.getText().toString());

                        if (deleteRows > 0)
                            Toast.makeText(MainActivity.this,"Dados excluidos",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this,"Dados não foram Excluidos",Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    public void AddData () {
        btnAdicionar.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = myDb.insertData(editMarca.getText().toString(),
                                editModelo.getText().toString(),
                                Integer.valueOf(editVelMax.getText().toString()));

                        if(isInserted = true)
                            Toast.makeText(MainActivity.this,"Dados Inseridos",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this,"Dados não foram Inseridos",Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    public void  viewAll () {
        btnTodos.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDb.getAllData();
                            if(res.getCount() == 0 ){
                                mostrarMensagem("Erro","Não foi encontrado resultados!");

                                return;
                            }

                            StringBuffer buffer = new StringBuffer();
                            while (res.moveToNext()) {
                                buffer.append("ID :" + res.getString(0) +"\n");
                                buffer.append("MARCA :" + res.getString(1) +"\n");
                                buffer.append("MODELO :" + res.getString(2) +"\n");
                                buffer.append("VEL_MAX :" + res.getString(3) +"\n\n");
                            }

                            mostrarMensagem("Dados",buffer.toString());

                    }
                }
        );
    }

    public void mostrarMensagem(String title, String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

    public void UpdateData() {
        btnUpdate.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isUpdate = myDb.updateData(editTextId.getText().toString(),editMarca.getText().toString(),
                                editModelo.getText().toString(),
                                editVelMax.getText().toString());

                        if(isUpdate == true){
                            mostrarMensagem("Sucesso","Dados Atualizados!");
                        }
                        else{
                            mostrarMensagem("Sucesso","Dados não foram atulizados!");
                        }
                    }
                }
        );
    }
}
